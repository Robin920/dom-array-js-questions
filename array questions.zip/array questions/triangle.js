//13. Write a script that prompt the user to enter base
//    and height of the triangle and calculate an area of a 
//    triangle (area = 0.5 x b x h).

const prompt=require("prompt-sync")({sigint:true}); 

const base = prompt('Enter the base of a triangle: ');
const height = prompt("Enter height of triangle: ");
console.log("Area of triangle: ",0.5*base*height);

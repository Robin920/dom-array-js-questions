/*16. Get radius using prompt and calculate the area of a circle
 (area = pi x r x r) and circumference of a circle(c = 2 x pi x r)
  where pi = 3.14.
*/

const prompt=require("prompt-sync")({sigint:true}); 
const radius = prompt("Enter radius of circle: ");

console.log("Area od circle: ",3.14*radius*radius);
console.log("Circumference of circlr: ",2*3.14*radius);

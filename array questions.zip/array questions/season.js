/*Q.21. Check if the season is Autumn, Winter, Spring or Summer. If the user input is :
    - September, October or November, the season is Autumn.
    - December, January or February, the season is Winter.
    - March, April or May, the season is Spring
    - June, July or August, the season is Summer
*/
const prompt=require("prompt-sync")({sigint:true});

let month = prompt("Enter the month: ");
month = month.toLocaleLowerCase();

if(month == 'september'||month == 'october'||month == 'november'){
    console.log("Autumn");
}else if(month == 'december'||month == 'january'||month == 'february'){
    console.log("Winter");
}else if(month == 'march'||month == 'april'||month == 'may'){
    console.log("Spring");
}else if(month == 'june'||month == 'july'||month == 'august'){
    console.log("Summer");
}else{
    console.log("Incorrect input");
}
/*14. Slope is m = (y2-y1)/(x2-x1). Find the slope between point (2, 2)
 and point(6,10)
*/
function slope(x1,y1,x2,y2){
    m = (y2-y1)/(x2-x1);
    console.log("Slope is: ",m);
}

slope(2,2,6,10);

console.log("---------------------------------------")

//Q15. Calculate the slope, x-intercept and y-intercept of y = 2x -2
const intercept = (m,b) => {
    console.log(`y-intercept: (0,${b})`);
    let xInter = -b/m;
    console.log(`x-intercept: (${xInter},0)`)
}
intercept(2,-2);

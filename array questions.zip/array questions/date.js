/*17. Create a human readable time format using the Date time object
    - YYYY-MM-DD HH:mm
    - DD-MM-YYYY HH:mm
    - DD/MM/YYYY HH:mm
*/
var date = new Date();
let str = date.toLocaleDateString();
str = str.split("/");

console.log(`${str[2]}-${str[1]}-${str[0]}  ${date.getHours()}:${date.getMinutes()}`);
console.log(`${str[0]}-${str[1]}-${str[2]}  ${date.getHours()}:${date.getMinutes()}`);
console.log(`${date.toLocaleDateString()}  ${date.getHours()}:${date.getMinutes()}`);

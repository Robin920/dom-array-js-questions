/*Q.24. Create a separate countries.js file and store the countries array in
 to this file, create a separate file web_techs.js and store the webTechs array
 in to this file. Access both file in main.js file
*/
let countries = ['india','kenya','africa','usa'];

export default countries;

import webTechs from "./web_techs.js";
import countries from "./countries.js";

console.log("webTechs: ",webTechs);
console.log("-----------------------------------------------------------------");
console.log("Countries: ",countries);
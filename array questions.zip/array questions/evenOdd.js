/*Q.19. Even numbers are divisible by 2 and the remainder is zero.
 How do you check, if a number is even or not using JavaScript?
*/


const prompt=require("prompt-sync")({sigint:true}); 

const num = prompt("Enter the number: ");
if(num%2 == 0){
    console.log(num," is even")
}else{
    console.log(num," is odd")
}
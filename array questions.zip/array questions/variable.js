//Q1
let x = "hey there";
console.log(x,"->",typeof x);

let a = true;
console.log(a,"->",typeof a);

let b;
console.log(b,"->",typeof b);

let c = null;
console.log(c,"->",typeof c);

//Q2
let info = {
    firstName: "Dewang",
    lastName: "Shekhar",
    maritalStatus: "bachelor",
    country: "India",
    age: 22,
}
console.log(`My name is ${info.firstName} ${info.lastName}, I'm ${info.age} years old 
${info.maritalStatus} living in ${info.country}`);

//Q3
let str = "dewang shekhar";
let str1 = str.toUpperCase();
console.log(str1);

//Q4
let txt = "Hey there this example Script";
let resTxt = txt.includes("Script");
resTxt?console.log("'Script' is prrsent in the string"):
console.log("'Script' is not present in the string");

//Q5
let txt1 = "Hey there this example Script"
let arrTxt = txt1.split(" ");
console.log(arrTxt);

//Q6
let txt2 = "Facebook, Google, Microsoft, Apple, IBM, Oracle, Amazon"
let arrTxt2 = txt2.split(", ");
console.log(arrTxt2);

//Q7
let text = "Hello planet earth, you are a great planet.";
let result = text.lastIndexOf("planet");
console.log(result);

//Q8
let txt3 = "You cannot end a sentence with because because because is a conjunction";
let resTxt3 = txt3.search("because");
console.log(resTxt3);

//Q9
let txt4 = "  Good vibes only    ";
txt4 = txt4.trim();
console.log(txt4);

//Q10
//truthy values
let stat1 = "hey";
let stat2 = 27;
let stat3 = [];
if(stat1 && stat2 && stat3){
    console.log("Truthy statements")
}
//falsy values
let fstat1 = "";
let fstat2 = null;
let fstat3 = 0;
if(!(fstat1 && fstat2 && fstat3)){
    console.log("Falsy statements")
}

//Q11
console.log(4 > 3);
console.log(4 >= 3);
console.log(4 < 3);
console.log(4 <= 3);
console.log(4 == 4);
console.log(4 === 4);
console.log(4 != 4);
console.log(4 !== 4);
console.log(4 != '4');
console.log(4 == '4');
console.log(4 === '4');

let txt5 = "python";
let txt5Len = txt5.length;
let txt6 = "jargon";
let txt6Len = txt6.length;
console.log(txt5Len != txt6Len);


//Q12
// - What is the year today?
// - What is the month today as a number?
// - What is the date today?
// - What is the day today as a number?
// - What is the hours now?
// - What is the minutes now?
// - Find out the numbers of seconds elapsed from January 1, 1970 to now.
console.log("Year -> ",new Date().getFullYear());
console.log("Month->",new Date().getMonth() +1);
console.log("Date today->",new Date().getDate());
console.log("Day today->",new Date().getDay() +1);
console.log("Hours now->",new Date().getHours());
console.log("Minutes now->",new Date().getMinutes());
let d = Date.now();
let sec = Math.floor( d / 1000 );;
console.log("Seconds from Jan 1,1970->", sec);




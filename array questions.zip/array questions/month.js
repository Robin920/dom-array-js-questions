//Q.22. Write a program which tells the number of days in a month.
//Q.23. Write a program which tells the number of days in a month, 
//      now consider leap year.

const prompt=require("prompt-sync")({sigint:true});

let month = prompt("Enter the month: ");
month = month.toLocaleLowerCase();

if(month == 'january'||month == 'may'||month == 'march'||month == 'july'||month == 'august'||month == 'october'||month == 'december'){
    console.log("number of days: 31");
}else if(month == 'february'){
    let year = new Date().getFullYear();
    (year%4 == 0)?console.log("number of days: 29"):console.log("number of days: 28")
}else{
    console.log("number of days: 30");
}
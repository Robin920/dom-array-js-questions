let webTechs = ['node','java','c++','react'];

export default webTechs;